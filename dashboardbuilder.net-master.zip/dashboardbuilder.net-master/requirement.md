REQUIREMENTS
-------------------------
    PHP Version 5 or later
    Apache 2 or later
    Windows 7 or later /Linux 3 or later
    Firefox 52, Chrome 57, IE 8
